def media(lista):
    """
    Retorna la media de una lista
    """
    return sum(lista)/len(lista)