def sumar(a, b):
    """
    Retorna la suma dos números
    """
    return a + b


def restar(a, b):
    """
    Retorna la resta dos números
    """
    return a - b


def multip(a, b):
    """
    Retorna la multiplicación dos números
    """
    print("Esto es el módulo de calculadora básica")
    return a * b


def div(a, b):
    """
    Retorna la división dos números
    """

    if b == 0:
        print("No se puede dividir por ceros.")
    return a / b